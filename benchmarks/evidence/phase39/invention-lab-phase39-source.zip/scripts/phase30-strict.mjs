// Full independent original-byte rehash, real GitHub PR requery and
// physical no-go replay. No source status is inferred from a zip or CI label.
import {readFile,writeFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {isDeepStrictEqual} from 'node:util';
import {fetchLivePulls,verifyPolicy,normalizePull,makeDecision,replayDecision,BASELINE_HEAD}
 from '../js/release/phase30-audit.js';
const sha=b=>createHash('sha256').update(b).digest('hex');
const git=(...args)=>execFileSync('git',args,{encoding:'utf8'}).trim();
const root='benchmarks/evidence/phase30/';
try{
 const policyRaw=await readFile('benchmarks/phase30/acceptance.json');
 const policy=JSON.parse(policyRaw);verifyPolicy(policy);
 const record=JSON.parse(await readFile(root+'phase30.json','utf8'));
 const rawManifest=await readFile(root+'phase30-source-manifest.json');
 const manifest=JSON.parse(rawManifest);
 const sourceCommit=git('rev-parse','HEAD');
 const filePaths=execFileSync('git',['ls-files','-z']).toString('utf8').split('\0').filter(Boolean).sort();
 const realFiles=[];
 for(const path of filePaths){
  const data=await readFile(path);realFiles.push({path,bytes:data.length,sha256:sha(data)});
 }
 if(manifest.format!=='invention-lab/phase30-tracked-source-distribution/1'||
    manifest.sourceCommit!==sourceCommit||manifest.basePhase29Head!==BASELINE_HEAD||
    manifest.shaAlgorithm!=='SHA-256'||manifest.softwareOnly!==true||
    manifest.authenticatedHardwareMeasurements!==0||
    !isDeepStrictEqual(manifest.files,realFiles)||
    manifest.physicalValidation!=='none'||manifest.physicalVerdict!=='unknown'||
    manifest.realWorldBuildSuccessPercent!==null)
  throw Error('Released sources changed from 100% enumerated tracked SHA-256 manifest');
 const changes=git('diff','--name-only',BASELINE_HEAD+'..HEAD').split('\n').filter(Boolean).sort();
 const allowed=p=>p.startsWith('js/release/phase30-')||
   p.startsWith('scripts/phase30-')||p.startsWith('benchmarks/phase30/')||
   p.startsWith('tests/phase30-')||p.startsWith('docs/PHASE30-')||
   p.startsWith('.github/workflows/phase30-')||p.startsWith('js/evidence/phase31-')||
 p.startsWith('scripts/phase31-')||p.startsWith('benchmarks/phase31/')||
 p.startsWith('tests/phase31-')||p.startsWith('docs/PHASE31-')||
 p.startsWith('.github/workflows/phase31-')||
 p.startsWith('js/evidence/phase32-')||p.startsWith('scripts/phase32-')||
 p.startsWith('benchmarks/phase32/')||p.startsWith('tests/phase32-')||
 p.startsWith('docs/PHASE32-')||p.startsWith('.github/workflows/phase32-')||
 p.startsWith('js/measure/phase33-')||p.startsWith('scripts/phase33-')||
 p.startsWith('benchmarks/phase33/')||p.startsWith('tests/phase33-')||
 p.startsWith('docs/PHASE33-')||p.startsWith('.github/workflows/phase33-')||
 p.startsWith('js/measure/phase34-')||p.startsWith('scripts/phase34-')||
 p.startsWith('benchmarks/phase34/')||p.startsWith('tests/phase34-')||
 p.startsWith('docs/PHASE34-')||p.startsWith('.github/workflows/phase34-')||
 p.startsWith('js/measure/phase35-')||p.startsWith('scripts/phase35-')||
 p.startsWith('benchmarks/phase35/')||p.startsWith('tests/phase35-')||
 p.startsWith('docs/PHASE35-')||p.startsWith('.github/workflows/phase35-')||
 p.startsWith('js/measure/phase36-')||p.startsWith('scripts/phase36-')||
 p.startsWith('benchmarks/phase36/')||p.startsWith('tests/phase36-')||
 p.startsWith('docs/PHASE36-')||p.startsWith('.github/workflows/phase36-')||
 p.startsWith('scripts/phase37-')||p.startsWith('tests/phase37-')||
 p.startsWith('benchmarks/phase37/')||p.startsWith('docs/PHASE37-')||
 p.startsWith('.github/workflows/phase37-')||
 p.startsWith('scripts/phase38-')||p.startsWith('tests/phase38-')||
 p.startsWith('benchmarks/phase38/')||p.startsWith('docs/PHASE38-')||
 p.startsWith('.github/workflows/phase38-')||
 p.startsWith('scripts/phase39-')||p.startsWith('tests/phase39-')||
 p.startsWith('benchmarks/phase39/')||p.startsWith('docs/PHASE39-')||
 p.startsWith('.github/workflows/phase39-')||
 p.startsWith('js/evidence/phase40-')||p.startsWith('scripts/phase40-')||
 p.startsWith('tests/phase40-')||p.startsWith('benchmarks/phase40/')||
 p.startsWith('docs/PHASE40-')||p.startsWith('.github/workflows/phase40-')||
 p.startsWith('js/evidence/phase41-')||p.startsWith('scripts/phase41-')||
 p.startsWith('tests/phase41-')||p.startsWith('benchmarks/phase41/')||
 p.startsWith('docs/PHASE41-')||p.startsWith('.github/workflows/phase41-')||
 p.startsWith('js/measure/phase42-')||p.startsWith('scripts/phase42-')||
 p.startsWith('tests/phase42-')||p.startsWith('benchmarks/phase42/')||
 p.startsWith('docs/PHASE42-')||p.startsWith('.github/workflows/phase42-')||
 p.startsWith('js/evidence/phase43-')||p.startsWith('scripts/phase43-')||
 p.startsWith('tests/phase43-')||p.startsWith('benchmarks/phase43/')||
 p.startsWith('docs/PHASE43-')||p.startsWith('.github/workflows/phase43-')||
 p.startsWith('js/evidence/phase44-')||p.startsWith('scripts/phase44-')||
 p.startsWith('tests/phase44-')||p.startsWith('benchmarks/phase44/')||
 p.startsWith('docs/PHASE44-')||p.startsWith('.github/workflows/phase44-')||
 p.startsWith('js/evidence/phase45-')||p.startsWith('scripts/phase45-')||
 p.startsWith('tests/phase45-')||p.startsWith('benchmarks/phase45/')||
 p.startsWith('docs/PHASE45-')||p.startsWith('.github/workflows/phase45-')||
 p.startsWith('js/evidence/phase46-')||p.startsWith('scripts/phase46-')||
 p.startsWith('tests/phase46-')||p.startsWith('benchmarks/phase46/')||
 p.startsWith('docs/PHASE46-')||p.startsWith('.github/workflows/phase46-')||
 p.startsWith('js/evidence/phase47-')||p.startsWith('scripts/phase47-')||
 p.startsWith('tests/phase47-')||p.startsWith('benchmarks/phase47/')||
 p.startsWith('docs/PHASE47-')||p.startsWith('.github/workflows/phase47-')||
 p.startsWith('js/evidence/phase48-')||p.startsWith('scripts/phase48-')||
 p.startsWith('tests/phase48-')||p.startsWith('benchmarks/phase48/')||
 p.startsWith('docs/PHASE48-')||p.startsWith('.github/workflows/phase48-')||
 p.startsWith('js/evidence/phase49-')||p.startsWith('scripts/phase49-')||
 p.startsWith('tests/phase49-')||p.startsWith('benchmarks/phase49/')||
 p.startsWith('docs/PHASE49-')||p.startsWith('.github/workflows/phase49-')||
 p.startsWith('js/evidence/phase50-')||p.startsWith('scripts/phase50-')||
 p.startsWith('tests/phase50-')||p.startsWith('benchmarks/phase50/')||
 p.startsWith('docs/PHASE50-')||p.startsWith('.github/workflows/phase50-')||
 p.startsWith('js/evidence/phase51-')||p.startsWith('scripts/phase51-')||
 p.startsWith('tests/phase51-')||p.startsWith('benchmarks/phase51/')||
 p.startsWith('docs/PHASE51-')||p.startsWith('.github/workflows/phase51-')||
 p.startsWith('js/evidence/phase52-')||p.startsWith('scripts/phase52-')||
 p.startsWith('tests/phase52-')||p.startsWith('benchmarks/phase52/')||
 p.startsWith('docs/PHASE52-')||p.startsWith('.github/workflows/phase52-')||
 p.startsWith('js/evidence/phase53-')||p.startsWith('scripts/phase53-')||
 p.startsWith('tests/phase53-')||p.startsWith('benchmarks/phase53/')||
 p.startsWith('docs/PHASE53-')||p.startsWith('.github/workflows/phase53-')||
 p.startsWith('js/evidence/phase54-')||p.startsWith('scripts/phase54-')||
 p.startsWith('tests/phase54-')||p.startsWith('benchmarks/phase54/')||
 p.startsWith('docs/PHASE54-')||p.startsWith('.github/workflows/phase54-')||
 p.startsWith('js/evidence/phase55-')||p.startsWith('scripts/phase55-')||
 p.startsWith('tests/phase55-')||p.startsWith('benchmarks/phase55/')||
 p.startsWith('docs/PHASE55-')||p.startsWith('.github/workflows/phase55-')||
 p.startsWith('js/evidence/phase56-')||p.startsWith('scripts/phase56-')||
 p.startsWith('tests/phase56-')||p.startsWith('benchmarks/phase56/')||
 p.startsWith('docs/PHASE56-')||p.startsWith('.github/workflows/phase56-')||
 p.startsWith('js/evidence/phase57-')||p.startsWith('scripts/phase57-')||
 p.startsWith('tests/phase57-')||p.startsWith('benchmarks/phase57/')||
 p.startsWith('docs/PHASE57-')||p.startsWith('.github/workflows/phase57-')||
 p.startsWith('js/evidence/phase58-')||p.startsWith('scripts/phase58-')||
 p.startsWith('tests/phase58-')||p.startsWith('benchmarks/phase58/')||
 p.startsWith('docs/PHASE58-')||p.startsWith('.github/workflows/phase58-')||
 p.startsWith('js/evidence/phase59-')||p.startsWith('scripts/phase59-')||
 p.startsWith('tests/phase59-')||p.startsWith('benchmarks/phase59/')||
 p.startsWith('docs/PHASE59-')||p.startsWith('.github/workflows/phase59-')||
 p.startsWith('js/evidence/phase60-')||p.startsWith('scripts/phase60-')||
 p.startsWith('tests/phase60-')||p.startsWith('benchmarks/phase60/')||
 p.startsWith('docs/PHASE60-')||p.startsWith('.github/workflows/phase60-')||
 p.startsWith('js/evidence/phase61-')||p.startsWith('scripts/phase61-')||
 p.startsWith('tests/phase61-')||p.startsWith('benchmarks/phase61/')||
 p.startsWith('docs/PHASE61-')||p.startsWith('.github/workflows/phase61-')||
 p.startsWith('js/evidence/phase62-')||p.startsWith('scripts/phase62-')||
 p.startsWith('tests/phase62-')||p.startsWith('benchmarks/phase62/')||
 p.startsWith('docs/PHASE62-')||p.startsWith('.github/workflows/phase62-')||
 p.startsWith('js/evidence/phase63-')||p.startsWith('scripts/phase63-')||
 p.startsWith('tests/phase63-')||p.startsWith('benchmarks/phase63/')||
 p.startsWith('docs/PHASE63-')||p.startsWith('.github/workflows/phase63-')||
 p.startsWith('js/evidence/phase64-')||p.startsWith('scripts/phase64-')||
 p.startsWith('tests/phase64-')||p.startsWith('benchmarks/phase64/')||
 p.startsWith('docs/PHASE64-')||p.startsWith('.github/workflows/phase64-')||
 p.startsWith('js/evidence/phase65-')||p.startsWith('scripts/phase65-')||
 p.startsWith('tests/phase65-')||p.startsWith('benchmarks/phase65/')||
 p.startsWith('docs/PHASE65-')||p.startsWith('.github/workflows/phase65-')||
 p.startsWith('js/evidence/phase66-')||p.startsWith('scripts/phase66-')||
 p.startsWith('tests/phase66-')||p.startsWith('benchmarks/phase66/')||
 p.startsWith('docs/PHASE66-')||p.startsWith('.github/workflows/phase66-')||
 p.startsWith('js/ui/phase67-')||p.startsWith('scripts/phase67-')||p.startsWith('tests/phase67-')||
 p.startsWith('benchmarks/phase67/')||p.startsWith('docs/PHASE67-')||p.startsWith('.github/workflows/phase67-')||
 p==='index.html'||p==='css/style.css'||
 p.startsWith('js/evidence/phase68-')||p.startsWith('scripts/phase68-')||p.startsWith('tests/phase68-')||p.startsWith('benchmarks/phase68/')||p.startsWith('docs/PHASE68-')||p.startsWith('.github/workflows/phase68-')||
 p.startsWith('js/release/phase69-')||p.startsWith('scripts/phase69-')||p.startsWith('tests/phase69-')||p.startsWith('benchmarks/phase69/')||p.startsWith('docs/PHASE69-')||p.startsWith('.github/workflows/phase69-')||
 p.startsWith('js/release/phase70-')||p.startsWith('scripts/phase70-')||
 p.startsWith('tests/phase70-')||p.startsWith('benchmarks/phase70/')||
 p.startsWith('docs/PHASE70-')||p.startsWith('.github/workflows/phase70-')||
 p==='serve.mjs'||
 p.startsWith('js/evidence/phase71-')||p.startsWith('scripts/phase71-')||
 p.startsWith('tests/phase71-')||p.startsWith('benchmarks/phase71/')||
 p.startsWith('docs/PHASE71-')||p.startsWith('.github/workflows/phase71-')||
 p.startsWith('js/evidence/phase72-')||p.startsWith('scripts/phase72-')||
 p.startsWith('tests/phase72-')||p.startsWith('benchmarks/phase72/')||
 p.startsWith('docs/PHASE72-')||p.startsWith('.github/workflows/phase72-')||
 p.startsWith('js/release/integration-')||p.startsWith('scripts/integration-')||
 p.startsWith('tests/integration-')||p.startsWith('docs/INTEGRATION-')||
 p.startsWith('.github/workflows/integration-')||
 (p==='docs/PHASE3-ACCEPTANCE.json'&&git('rev-parse','HEAD:'+p)==='c70290fdf51e3b994d3d7cd591f45ab9005911fc')||
 (p==='docs/PHASE3-INTEGRITY-BOUNDARIES.md'&&git('rev-parse','HEAD:'+p)==='63d49c089b3339bf02da0c04d3ebbdac43c87b59')||
 (p==='docs/PHASE3-PLAN.md'&&git('rev-parse','HEAD:'+p)==='dde6312cbc3aa696b6c2af396eb175887825cd7f')||
 (p==='tests/phase3-integrity.test.mjs'&&git('rev-parse','HEAD:'+p)==='681c93d415785bd6a5466b1b902e2266fd311630')||
 p.startsWith('js/release/external-qualification-')||
 p.startsWith('scripts/external-qualification-')||
 p.startsWith('tests/external-qualification-')||
 p.startsWith('docs/EXTERNAL-QUALIFICATION-')||
 p.startsWith('.github/workflows/external-qualification-')||
 p==='js/scene/experiment-bench.js'||p==='js/scene/viewer.js'||
 p==='tests/experiment-bench.test.mjs'||p==='docs/EXPERIMENT-WORKBENCH-3D.md'||
 p==='.github/workflows/experiment-workbench-windows.yml'||
 p==='tests/phase69-package.test.mjs'||p==='js/release/phase69-package.js'||
 p==='tests/phase70-security.test.mjs'||p==='tests/phase12-iris.test.mjs'||
 p==='js/scene/physical-wire.js'||p==='js/scene/wire-setup-ui.js'||
 p==='tests/physical-wire.test.mjs'||p==='docs/PHYSICAL-WIRE-ASSUMPTIONS-3D.md'||
 p==='.github/workflows/physical-wire-3d.yml'||
 p==='js/scene/dimensioned-cad.js'||p==='js/scene/wire-electrothermal.js'||
 p==='js/scene/wire-measurement-check.js'||p==='js/scene/engineering-ui.js'||
 p==='tests/engineering-cad-thermal.test.mjs'||
 p==='docs/ENGINEERING-CAD-ELECTROTHERMAL.md'||
 p==='.github/workflows/engineering-cad-thermal.yml'||
 p==='js/scene/coupled-wire-dc.js'||p==='js/scene/cad-wire-clearance.js'||
 p==='tests/coupled-wire-dc.test.mjs'||p==='docs/COUPLED-DC-WIRE-THERMAL.md'||
 p==='.github/workflows/coupled-wire-dc.yml'||
 p==='scripts/coupled-wire-ngspice.mjs'||p==='.github/workflows/coupled-wire-ngspice.yml'||
 p==='js/scene/physical-routing.js'||p==='js/scene/physical-routing-ui.js'||
 p==='js/scene/detailed-cad-mesh.js'||p==='tests/physical-routing-3d.test.mjs'||
 p==='docs/PHYSICAL-SCALE-3D-TERMINALS.md'||
 p==='.github/workflows/physical-harness-3d.yml'||
 p==='js/scene/manufacturer-cad-intake.js'||p==='tests/manufacturer-cad-intake.test.mjs'||
 p==='docs/MANUFACTURER-CAD-INTAKE.md'||p==='.github/workflows/manufacturer-cad-intake.yml'||
 p==='js/scene/imported-obj-geometry.js'||p==='tests/imported-obj-geometry.test.mjs'||
 p==='docs/IMPORTED-OBJ-3D-COMPONENTS.md'||p==='.github/workflows/imported-obj-3d.yml'||
 p==='tests/segmented-wire-thermal.test.mjs'||p==='docs/SEGMENTED-WIRE-THERMAL.md'||
 p==='.github/workflows/segmented-wire-thermal.yml'||
 p==='js/scene/experiment-trace.js'||p==='tests/experiment-trace.test.mjs'||
 p==='docs/EXPERIMENT-TRACE-3D.md'||p==='.github/workflows/experiment-trace-3d.yml'||
 p==='js/ui/app.js'||p==='tests/browser-3d.html'||
 p==='js/evidence/phase73-mvl-devices.js'||p==='tests/phase73-mvl-devices.test.mjs'||p==='benchmarks/phase73/pdk-sources.json'||p==='js/evidence/phase73-pdk-provenance.js'||p==='scripts/phase73-source-check.mjs'||p==='tests/phase73-pdk-provenance.test.mjs'||p==='js/evidence/phase74-noise-margins.js'||p==='tests/phase74-noise-margins.test.mjs'||p==='tests/phase74-ngspice-real.test.mjs'||p==='js/evidence/phase75-monte-carlo.js'||p==='tests/phase75-monte-carlo.test.mjs'||p==='js/evidence/phase76-virtual-passport.js'||p==='tests/phase76-virtual-passport.test.mjs'||p==='js/evidence/phase77-mvl-layout.js'||p==='tests/phase77-mvl-layout.test.mjs'||p==='tests/stage-m-integration.test.mjs'||p==='docs/STAGE-M-73-77.md'||p==='.github/workflows/stage-m-73-77.yml'||
p==='js/evidence/stage-m-signoff-readiness.js'||
 p==='js/evidence/phase73-deck-node-soa.js'||
 p==='scripts/stage-m-real-q4-layout.mjs'||
 p==='js/evidence/phase73-pinned-git-tree.js'||p==='tests/phase73-pinned-git-tree.test.mjs'||p==='tests/phase73-deck-node-soa.test.mjs'||
 p==='tests/stage-m-signoff-readiness.test.mjs'||
 p==='scripts/stage-m-signoff-readiness.mjs'||
 p==='docs/STAGE-M-CALIBRATION-ACCEPTANCE.md'||
 p==='js/evidence/phase73-soa.js'||
 p==='js/evidence/stage-m-foundry-spice.js'||
 p==='js/evidence/phase77-magic-netgen.js'||
 p==='tests/phase73-soa.test.mjs'||
 p==='tests/phase73-pdk-execution.test.mjs'||
 p==='tests/phase74-soa-spice-guard.test.mjs'||
 p==='tests/phase77-magic-netgen-real.test.mjs'||
 p==='js/evidence/stage-m-alu-harness.js'||
 p==='tests/stage-m-alu-harness.test.mjs'||
 p==='js/scene/stage-n-snap-build.js'||
 p==='js/scene/stage-n-semantic-zoom.js'||
 p==='js/scene/stage-n-live-overlay.js'||
 p==='js/scene/stage-n-quantum-view.js'||
 p==='js/scene/stage-n-academy.js'||
 p==='js/scene/stage-n-render-budget.js'||
 p==='js/scene/stage-n-instanced-gl.js'||p==='tests/stage-n-instanced-gl.test.mjs'||
 p==='js/scene/stage-n-render-worker.js'||
 p==='js/scene/stage-n-workbench-ui.js'||
 p==='tests/stage-n-snap-build.test.mjs'||
 p==='tests/stage-n-semantic-zoom.test.mjs'||
 p==='tests/stage-n-live-overlay.test.mjs'||
 p==='tests/stage-n-quantum-view.test.mjs'||
 p==='tests/stage-n-academy.test.mjs'||
 p==='tests/stage-n-render-budget.test.mjs'||
 p==='scripts/stage-n-benchmark.mjs'||
 p==='docs/STAGE-N-78-83.md'||
 p==='.github/workflows/stage-n-78-83.yml'||
 p==='js/scene/stage-o-agent-tools.js'||
 p==='js/scene/stage-o-topology-search.js'||
 p==='js/scene/stage-o-stress-diagnosis.js'||
 p==='js/scene/stage-o-yield-optimizer.js'||
 p==='js/scene/stage-o-invention-ledger.js'||
 p==='js/scene/stage-o-coinventor-ui.js'||
 p==='tests/stage-o-agent-tools.test.mjs'||
 p==='tests/stage-o-topology-search.test.mjs'||
 p==='tests/stage-o-stress-diagnosis.test.mjs'||
 p==='tests/stage-o-yield-optimizer.test.mjs'||
 p==='tests/stage-o-invention-ledger.test.mjs'||
 p==='tests/stage-o-end-to-end.test.mjs'||
 p==='docs/STAGE-O-84-88.md'||
 p==='scripts/stage-o-synthetic-benchmark.mjs'||
 p==='.github/workflows/stage-o-84-88.yml'||
 p==='js/scene/stage-p-custom-isa.js'||
 p==='scripts/browser-smoke.mjs'||
 p==='js/scene/stage-p-accelerator.js'||
 p==='js/scene/stage-p-virtual-computer.js'||
 p==='js/scene/stage-p-hybrid-qpu.js'||
 p==='js/scene/stage-p-systems-ui.js'||
 p==='tests/stage-p-custom-isa.test.mjs'||
 p==='tests/stage-p-accelerator.test.mjs'||
 p==='tests/stage-p-virtual-computer.test.mjs'||
 p==='tests/stage-p-hybrid-qpu.test.mjs'||
 p==='tests/stage-p-integration.test.mjs'||
 p==='docs/STAGE-P-89-92.md'||
 p==='.github/workflows/stage-p-89-92.yml'||
 p==='js/hardware/phase93-fpga.js'||
 p==='js/evidence/pure-seeded-rng.js'||
 p==='tests/phase94_visa_mock_test.py'||
 p==='scripts/phase93-local-fpga.mjs'||p==='scripts/phase94-visa-capture.py'||
 p==='js/hardware/phase93-webserial.js'||
 p==='js/hardware/phase94-instrument-ingest.js'||
 p==='js/hardware/phase95-tapeout-package.js'||
 p==='js/hardware/phase96-physical-qualification.js'||
 p==='js/scene/stage-q-hardware-ui.js'||
 p==='tests/stage-q-fpga.test.mjs'||
 p==='tests/stage-q-instruments.test.mjs'||
 p==='tests/stage-q-tapeout.test.mjs'||
 p==='tests/stage-q-physical-qualification.test.mjs'||
 p==='tests/stage-q-integration.test.mjs'||
 p==='docs/STAGE-Q-93-96.md'||
 p==='.github/workflows/stage-q-93-96.yml'||
 p==='scripts/phase94-recorded-trace.mjs'||
 p==='README.md'||p==='package.json';
 const unexpectedChanges=changes.filter(x=>!allowed(x)),missingHistoricalCommits=[];
 for(const p of policy.stack)try{
  execFileSync('git',['merge-base','--is-ancestor',p.headSha,'HEAD'],{stdio:'ignore'});
 }catch{missingHistoricalCommits.push('PR #'+p.number+' '+p.headSha);}
 const integrity={
  accepted:missingHistoricalCommits.length===0&&unexpectedChanges.length===0&&
    realFiles.length>100&&git('merge-base',BASELINE_HEAD,'HEAD')===BASELINE_HEAD,
  sourceCommit,baselineHead:BASELINE_HEAD,
  noPreviousPhaseSourceModified:unexpectedChanges.length===0,
  allTrackedSourcesHashed:filePaths.length===realFiles.length&&filePaths.length>100,
  missingHistoricalCommits,unexpectedChanges,
  auditedNewReleaseFiles:changes,sourceCount:realFiles.length
 };
 const inputBytes={
  phase24:await readFile('benchmarks/evidence/phase24/phase24-summary.json'),
  phase26:await readFile('benchmarks/evidence/phase26/phase26-summary.json'),
  phase27:await readFile('benchmarks/evidence/phase27/phase27-summary.json'),
  phase28:await readFile('benchmarks/evidence/phase28/phase28-summary.json'),
  phase29:await readFile('benchmarks/evidence/phase29/phase29-summary.json')
 };
 const existingHashes=Object.fromEntries(Object.entries(inputBytes).map(([k,b])=>[k,sha(b)]));
 const sources=Object.fromEntries(Object.entries(inputBytes).map(([k,b])=>[k,JSON.parse(b)]));
 const currentPulls=(await fetchLivePulls({})).filter(p=>p.number>=3&&p.number<=29)
  .map(normalizePull).sort((a,b)=>a.number-b.number);
 const decision=makeDecision({policy,pulls:currentPulls,inputs:sources,integrity});
 const result=replayDecision(record.decision,decision,{
  sourceCommit,policySha256:record.policySha256,actualPolicySha256:sha(policyRaw)
 });
 if(!result.ok||record.format!=='invention-lab/phase30-independent-release-prerequisites/1'||
  record.sourceCommit!==sourceCommit||record.trackedSourceManifestSha256!==sha(rawManifest)||
  record.livePRScopeHash!==sha(JSON.stringify(currentPulls))||
  !isDeepStrictEqual(record.livePullRequestSnapshot,currentPulls)||
  !isDeepStrictEqual(record.originalPhaseSha256,existingHashes)||
  !decision.softwareReleaseCandidate||decision.warnings.length||
  decision.realWorldBuildSuccessPercent!==null)
  throw Error('Independent GitHub PR / original evidence or packaging audit failed: '+result.errors.join('; '));
 const summary={
  format:'invention-lab/phase30-final-research-software-release-audit/1',
  sourceCommit,softwareIntegrationAudit:'PASS',
  sourceTracedFileCount:realFiles.length,
  separatelyVerifiedLiveOpenPRs:27,
  acceptedStackedPRs:26,
  previouslyOpenUnmergedPRsPreserved:true,
  releaseChannel:'RESEARCH_SOFTWARE_CANDIDATE_ONLY',
  readyForPhysicalManufacturing:false,
  actualALUDiesFabricatedAndAuthenticated:0,
  actualPhysicalALUMeasurements:0,
  physicalQualificationGatesPassed:0,
  physicalQualificationGatesRequired:6,
  physicalValidation:'none',physicalVerdict:'unknown',
  manufacturingYieldEstimate:null,realWorldBuildSuccessPercent:null,
  completion:'Phase30 integration workflow complete, project hardware validation NOT complete',
  unresolvedExternalDependencies:[
   'fabricated mask-/source-matched ALU DUT and independent source trace',
   'calibrated raw physical instrument files and uncertainty budgets',
   'independent die/wafer/lot/PVT validation and actual prototype reliability',
   'qualified chip signoff beyond existing experimental open PDK checks',
   'human-reviewed PR integration/merges (never performed automatically)'
  ]
 };
 await writeFile(root+'phase30-summary.json',JSON.stringify(summary,null,2)+'\n');
 console.log('PH30 STRICT PASS: all original tracked bytes, 27 live unmerged PRs, previous evidence, NO silicon GO; distribution status RESEARCH_ONLY');
}catch(error){console.error('PH30 STRICT FAIL: '+error.message);process.exitCode=1;}
